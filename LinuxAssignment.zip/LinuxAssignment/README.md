# LinuxAssignment

Q1. You will find a text file in the root of this directory named 'change_john_to_yourName'. Make a compound command that takes this file, finds all accourances of the name 'John' and replace it with your name, and save it in a new text file named 'yourName.txt'

Q2. Create a BASH SCRIPT that does the following:
- Create a new folder called `my-app`
- Inside `my-app` create two new empty files called `README.md` and `package.json`
- Inside of `my-app` create a new folder called `public`. Inside `public`, create an `index.html` file.
- Create a new folder called `src` inside of `my-app`.  Navigate inside of it.
- Create the following four files inside of `src`: `App.css`, `App.js`, `index.css`, and `index.js`
- Make your script as verbose as possible.
- Your folder structure should now look like this:

    ```bash
    my-app/
        README.md
        package.json
    public/
        index.html
    src/
        App.css
        App.js
        index.css
        index.js
    ```